//
//  Get.swift
//  CaritasCollect
//
//  Created by Alumno on 07/09/23.
//

import Foundation

struct Get : Codable {
    var _id_recolector: Int
    var mensaje: String
    var success: Bool
}

