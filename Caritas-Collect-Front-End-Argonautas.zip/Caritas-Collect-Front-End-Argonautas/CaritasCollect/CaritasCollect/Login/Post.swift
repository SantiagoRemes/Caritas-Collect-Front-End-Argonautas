//
//  Post.swift
//  CaritasCollect
//
//  Created by Alumno on 07/09/23.
//

import Foundation

struct Post: Codable {
    var id: Int
    var title: String
}
