//
//  ConfiguracionView.swift
//  CaritasCollect
//
//  Created by Alumno on 06/09/23.
//

import SwiftUI

struct ConfiguracionView: View {
    var body: some View {
        Text("Configuracion")
    }
}

struct ConfiguracionView_Previews: PreviewProvider {
    static var previews: some View {
        ConfiguracionView()
    }
}
