//
//  Recoleccion.swift
//  CaritasCollect
//
//  Created by Alumno on 06/09/23.
//

import Foundation

struct Recoleccion : Codable, Identifiable{
    let id : Int
    let direccion : String
    
}
