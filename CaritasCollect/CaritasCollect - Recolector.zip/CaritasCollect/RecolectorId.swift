//
//  RecolectorId.swift
//  CaritasCollect
//
//  Created by Santiago Remes Inguanzo on 28/09/2023.
//

import Foundation

var idRecolector = 0

var regresar = false
var refresh = false
